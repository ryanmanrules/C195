module lynch.firstscreen {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires mysql.connector.java;


    opens lynch.firstscreen to javafx.fxml;
    exports lynch.firstscreen;
}