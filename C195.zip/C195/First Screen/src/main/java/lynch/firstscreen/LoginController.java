package lynch.firstscreen;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.animation.TranslateTransition;

public class LoginController {
    private ResourceBundle bundle;


    @FXML
    private TextField userNameEntry;

    @FXML
    private PasswordField passwordEntry;

    @FXML
    private Label logInErrorLog;

    @FXML
    private Label TimeZone;

    @FXML
    private Button logInButton;






    @FXML
    public void initialize() {
        Locale locale = Locale.getDefault();
        ResourceBundle bundle = ResourceBundle.getBundle("lynch.firstscreen.Language.MessagesBundle", locale);

        // Set labels and button text from the resource bundle
        userNameEntry.setText(bundle.getString("username_label"));
        passwordEntry.setText(bundle.getString("password_label"));
        logInButton.setText(bundle.getString("login_button"));
        TimeZone.setText(bundle.getString("timezone_label") + ": " + java.time.ZoneId.systemDefault().toString());

        TimeZone.setText(java.time.ZoneId.systemDefault().toString());


    }

    // Updated login button method to use localized messages
    @FXML
    private void onLoginButtonClicked() {
        String username = userNameEntry.getText();
        String password = passwordEntry.getText();

        if (username.equals("user") && password.equals("password")) {
            logInErrorLog.setText(bundle.getString("login_success"));
        } else {
            logInErrorLog.setText(bundle.getString("login_error"));
        }




    }


}

