package lynch.firstscreen;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {
    private static final String url = "jdbc:mysql://wgudb.ucertify.com:3306/client_schedule?connectionTimeZone=SERVER";
    private static final String user = "sqlUser";  // Replace with actual username
    private static final String password = "Passw0rd";  // Replace with actual password
    private static Connection conn;

    /**
     * Opens a connection to the database.
     */
    public static void openConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");  // Ensure the driver is loaded
            conn = DriverManager.getConnection(url, user, password);
            System.out.println("Database connection successful.");
        } catch (SQLException e) {
            System.err.println("SQL Exception: " + e.getMessage());
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.err.println("Class Not Found Exception: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Gets the current database connection.
     * @return the connection to the database
     */
    public static Connection getConnection() {
        return conn;
    }

    /**
     * Closes the connection to the database.
     */
    public static void closeConnection() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
                System.out.println("Database connection closed.");
            }
        } catch (SQLException e) {
            System.err.println("SQL Exception on closing: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
