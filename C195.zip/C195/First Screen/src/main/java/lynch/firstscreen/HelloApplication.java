package lynch.firstscreen;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import lynch.firstscreen.Database;

import java.util.Locale;
import java.util.ResourceBundle;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) {
        Database.openConnection(); // Open the connection at the start
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Login.fxml"));
            ResourceBundle bundle = ResourceBundle.getBundle("lynch.firstscreen.Language.MessagesBundle", Locale.getDefault());
            fxmlLoader.setResources(bundle);
            Scene scene = new Scene(fxmlLoader.load(), 320, 240);
            stage.setTitle(bundle.getString("login_title"));
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Database.closeConnection(); // Close the connection when the application exits
        }
    }

    public static void main(String[] args) {
        launch();
    }
}
